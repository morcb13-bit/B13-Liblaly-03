"""第2章 2.x の検定：ペンローズの鎖の上で 2 と 3 の打ちを形として読む。
道具は前の記事の b13_chain_units.py と chain_balanced.py（そのまま使う）。"""
import json, sys
import b13_chain_units as B
import chain_balanced as CB

def has_skip(n):
    L = CB.links(B.unit(n))
    return any(l in B.SKIP for l in L)

def trial_prime(n):          # 照合用（観察者側）：足し重ねて届くかで素数を確かめる
    if n < 2: return False
    for d in range(2, n):
        v = d + d
        while v < n: v += d
        if v == n: return False
    return True

if __name__ == "__main__":
    print(" n  2つ飛ばし  独立の1  残る  素数")
    rows = []
    for n in range(1, 30):
        sk = has_skip(n)
        ones = None if sk else CB.min_ones(n)
        if n == 1: left = "1"
        elif n in (2, 3): left = "打つ数"
        elif sk: left = "2で落ちる"
        elif ones == 0: left = "3で落ちる"
        else: left = "残る"
        rows.append((n, sk, ones, left, trial_prime(n)))
        print(f"{n:>2}  {'あり' if sk else 'なし':<6}  {'-' if ones is None else ones:>4}   {left:<6} {'素数' if trial_prime(n) else ''}")
    surv = [n for n, sk, o, l, p in rows if l == "残る"]
    pr = [n for n, sk, o, l, p in rows if p and n > 3]
    print("残る数:", surv)
    print("4〜29 の素数:", pr)
    print("残るが素数でない:", [n for n in surv if n not in pr])
    print("素数なのに落ちる:", [n for n in pr if n not in surv])

    # 動く図のデータ：13 行の三角形（表示用の座標は観察者側）
    rws, place, offs = B.build_stack()
    data = []
    for ri, cs in enumerate(place):
        n = B.ROW_ORDER[ri]
        rings = []
        for c in cs:
            pents = []
            for q, k in B.ring_cells(c):
                pts = [B.xy(B.zadd(q, B.zt(k + 2 * i))) for i in range(5)]
                pents.append([[round(x, 2), round(y, 2)] for x, y in pts])
            rings.append(pents)
        cover = None
        if not has_skip(n) and n > 1:
            d, cov, cent = CB.balanced(n)[:3]
            cover = {"digit": d, "vs": cov, "center": cent}
        data.append({"n": n, "skip": has_skip(n), "rings": rings, "cover": cover})
    json.dump(data, open("triangle.json", "w"), separators=(",", ":"))
    print("triangle.json を書き出した")
