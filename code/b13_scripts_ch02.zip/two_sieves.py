"""第2章の検定：同じ骨組みの篩で、一行だけ替えると素数と幸運数に分かれる。
足し算と数えることだけを使う（割り算・剰余・小数なし）。"""
import sys

def sieve(N, rule):
    """1..N の列から始める。2 番目の生き残りから順に「選ぶ数 s」を取り、
    rule="値"  : s+s, s+s+s, … の値を持つ生き残りに印をつけて外す（s ずつ足す）
    rule="番目": 生き残りを 1 から数えて s 番目ごとに外す（s 個ずつ数える）"""
    seq = list(range(1, N + 1))
    prev = 1                          # 次に選ぶのは「前に選んだ数の次の生き残り」
    while True:
        nxt = [x for x in seq if x > prev]
        if not nxt: break
        s = nxt[0]
        if rule == "値":
            if s + s > N: break
            hit = set()
            v = s + s
            while v <= N:
                hit.add(v); v += s
            seq = [x for x in seq if x not in hit]
        else:
            if s > len(seq): break
            out, c = [], 0
            for x in seq:
                c += 1
                if c == s: c = 0
                else: out.append(x)
            seq = out
        prev = s
    return seq

def by_trial(N):
    """照合用：素数を「どの数を足し重ねても届かない」ことで別に確かめる。"""
    out = []
    for n in range(2, N + 1):
        ok = True
        d = 2
        while d + d <= n and ok:
            v = d + d
            while v < n: v += d
            if v == n: ok = False
            d += 1
        if ok: out.append(n)
    return out

LUCKY_KNOWN = [1, 3, 7, 9, 13, 15, 21, 25, 31, 33, 37, 43, 49, 51, 63, 67, 69, 73, 75, 79, 87, 93, 99]

if __name__ == "__main__":
    print("== 検定A：一行だけ替える")
    P = sieve(100, "値"); L = sieve(100, "番目")
    print("値で印  :", P)
    print("番目で抜く:", L)
    tA1 = P == [1] + by_trial(100)
    tA2 = L == LUCKY_KNOWN
    print("値で印 = 1 と素数（別の方法で確かめた列）:", "OK" if tA1 else "NG")
    print("番目で抜く = 幸運数（知られている最初の 23 個）:", "OK" if tA2 else "NG")

    print("== 検定B：数を比べる")
    N = 100000
    P = sieve(N, "値")[1:]   # 1 を除く
    L = sieve(N, "番目")
    for M in (100, 1000, 10000, 100000):
        cp = sum(1 for x in P if x <= M); cl = sum(1 for x in L if x <= M)
        print(f"{M:>7} まで  素数 {cp:>5}  幸運数 {cl:>5}  差 {cl - cp:>5}")
    tw_p = sum(1 for x in P if x + 2 in set(P))
    sl = set(L)
    tw_l = sum(1 for x in L if x + 2 in sl)
    print(f"差が 2 の組（双子）  素数 {tw_p}  幸運数 {tw_l}")

    print("== 検定C：偶数を二つの和で書けるか（4〜20000 の偶数）")
    def goldbach(S, lo, hi):
        Sset = set(S); miss = []
        e = lo
        while e <= hi:
            if not any((e - x) in Sset for x in S if x <= e): miss.append(e)
            e += 2
        return miss
    sp = [x for x in P if x <= 20000]; slk = [x for x in L if x <= 20000]
    mp = goldbach(sp, 4, 20000); ml = goldbach(slk, 2, 20000)
    # 負の対照：1 から 4 ずつ足した列（1, 5, 9, …）
    ctrl = []; v = 1
    while v <= 20000: ctrl.append(v); v += 4
    mc = goldbach(ctrl, 2, 20000)
    print("素数   で書けない偶数:", len(mp), mp[:5])
    print("幸運数 で書けない偶数:", len(ml), ml[:5])
    print("対照（1,5,9,…）で書けない偶数:", len(mc), mc[:5])
