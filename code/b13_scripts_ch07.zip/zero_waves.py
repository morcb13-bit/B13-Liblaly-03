"""検定F と図1のデータ：零点の波を K 本重ねて、チェビシェフの階段 ψ(x) を描く（明示公式）。
零点の値と波の高さは観察者側の小数（mpmath）。ψ(x) の段の位置と高さの基準は整数の篩から。"""
import json, mpmath as mp
mp.mp.dps = 20
K = 60
zeros = [float(mp.im(mp.zetazero(n))) for n in range(1, K + 1)]
import math
def psi_true(x):
    s = 0.0
    for p in range(2, int(x) + 1):
        if all(p % d for d in range(2, int(p ** .5) + 1)):
            q = p
            while q <= x: s += math.log(p); q *= p
    return s
def psi_K(x, k, shift=0.0):
    s = x - math.log(2 * math.pi) - 0.5 * math.log(1 - x ** -2)
    for g in zeros[:k]:
        g = g + shift
        # 2 Re(x^ρ/ρ), ρ = 1/2 + iγ
        r = math.sqrt(x); a = g * math.log(x)
        s -= 2 * r * (0.5 * math.cos(a) + g * math.sin(a)) / (0.25 + g * g)
    return s
xs = [2 + i * 0.05 for i in range(int((40 - 2) / 0.05) + 1)]
mids = [n + 0.5 for n in range(2, 40)]
print("== 検定F：零点の波を K 本重ねた階段と、篩から作った階段の差（段の間の中点 38 か所の平均）")
res = {}
for k in (1, 5, 10, 20, 40, 60):
    e = sum(abs(psi_K(m, k) - psi_true(m)) for m in mids) / len(mids)
    ec = sum(abs(psi_K(m, k, 0.5) - psi_true(m)) for m in mids) / len(mids)
    res[k] = (e, ec)
    print("K=%2d  零点の波: %.3f   対照（零点を 0.5 ずらす）: %.3f" % (k, e, ec))
dec = all(res[a][0] > res[b][0] for a, b in ((1, 10), (10, 40), (40, 60)))
print("→ 零点の波は K とともに差が縮むか:", "OK" if dec else "NG", " ／ 対照は K=60 で零点の波より大きいか:", "OK（期待どおり）" if res[60][1] > 2 * res[60][0] else "NG")
data = {"zeros": zeros, "xs": xs, "psi": [psi_true(x) for x in xs],
        "curves": {str(k): [round(psi_K(x, k), 4) for x in xs] for k in (0, 1, 2, 3, 5, 10, 20, 40, 60)}}
json.dump(data, open("zero_waves.json", "w"))
