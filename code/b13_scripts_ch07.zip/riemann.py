"""第7章の検定。A〜E は整数と足し算・引き算・比べ合いだけで判定する。
F（零点の波）だけは、零点の値と波の高さを観察者側の小数で扱う。"""
import numpy as np

def sub_mod(a, p):                 # a を p で引き戻した余り（p を足して倍々にした物差しを、大きい順に引くだけ）
    if a < p: return a
    rulers = [p]
    while rulers[-1] + rulers[-1] <= a: rulers.append(rulers[-1] + rulers[-1])
    for r in reversed(rulers):
        if a >= r: a -= r
    return a
def gcd_sub(a, b):                 # 引き算の互除法
    while b:
        a = sub_mod(a, b)
        a, b = b, a
    return a

F = [0, 1]
for i in range(400): F.append(F[-1] + F[-2])

print("== 検定A：gcd(F(m), F(n)) = F(gcd(m, n))  (2 ≤ m, n ≤ 120)")
bad = 0; cnt = 0
for m in range(2, 121):
    for n in range(m + 1, 121):
        cnt += 1
        if gcd_sub(F[n], F[m]) != F[gcd_sub(n, m)]: bad += 1
print("組", cnt, "  食い違い", bad, "→", "OK" if bad == 0 else "NG")
G = [0, 1]
for i in range(130): G.append(G[-1] + G[-1] + G[-2])   # 対照：a(n) = 2a(n−1) + a(n−2)（ペル数）
bad2 = sum(1 for m in range(2, 61) for n in range(m + 1, 61) if gcd_sub(G[n], G[m]) != G[gcd_sub(n, m)])
H = [1, 1]
for i in range(130): H.append(H[-1] + H[-2] + 1)       # 対照：一歩ごとに 1 を足す列
bad3 = sum(1 for m in range(2, 61) for n in range(m + 1, 61) if gcd_sub(H[n], H[m]) != H[gcd_sub(n, m)])
print("対照 ペル数（同じ型の二項漸化式）の食い違い:", bad2, "／ 一歩ごとに 1 を足す列の食い違い:", bad3, "→", "NG（期待どおり）" if bad3 > 0 else "OK")

def primes_upto(n):
    c = bytearray(n + 1); c[0] = c[1] = 1
    p = 2
    while p * p <= n:
        if not c[p]:
            v = p * p
            while v <= n: c[v] = 1; v += p
        p += 1
    return [i for i in range(n + 1) if not c[i]]
P = primes_upto(10000)

print("== 検定B：10000 までの素数 p は、p + 1 歩以内にフィボナッチ数を刻むか。その番地 α は p − (5/p) を割り切るか")
ok = True; ALPHA = []
for p in P:
    a, b, k = 0, 1, 1
    while b != 0:
        a, b = b, sub_mod(a + b, p); k += 1
        if k > p + 1: break
    alpha = k              # F(alpha) ≡ 0 (mod p)
    r5 = sub_mod(p, 5)
    eps = 0 if p == 5 else (1 if r5 in (1, 4) else -1)
    target = p - eps
    t = target
    while t > 0: t -= alpha
    ok &= (alpha <= p + 1) and (t == 0); ALPHA.append((p, alpha))
print("素数", len(P), "個 →", "OK" if ok else "NG")
print("例:", ", ".join("%d→%d" % (p, a) for p, a in ALPHA if p in (2, 3, 5, 7, 11, 13, 89, 233)))

print("== 検定C：番地 n ≤ 100 の F(n) に、前のどの F(k) も刻まない新しい素数が入っているか（1, 2, 6, 12 を除く）")
from sympy import factorint
seen = set(); miss = []
for n in range(1, 101):
    fs = set(factorint(F[n]).keys()) if F[n] > 1 else set()
    new = fs - seen
    if not new: miss.append(n)
    seen |= fs
print("新しい素数が出なかった番地:", miss, "→", "OK" if miss == [1, 2, 6, 12] else "NG")
seen = set(); miss2 = []; D = 1
for n in range(1, 41):
    D = D + D
    fs = set(factorint(D).keys()); new = fs - seen
    if not new: miss2.append(n)
    seen |= fs
print("対照 倍々の列 2, 4, 8, …：新しい素数が出なかった番地の数", len(miss2), "/ 40 →", "NG（期待どおり：2 のあと一つも出ない）" if len(miss2) == 39 else "?")

print("== 検定D：最初の k 本の素数の波について、積 Pk で山の数 k、Pk + 1 で山の数 0")
ok = True; rows = []
for k in range(1, 11):
    ps = P[:k]; Pk = 1
    for p in ps: Pk *= p
    hitP = 0; hit1 = 0; hit2 = 0; hit3 = 0
    for p in ps:
        r = 0                                  # Pk を p で引き戻した余り（掛け算は小さな数どうし、引き戻しは引き算）
        rr = 1
        for q in ps: rr = sub_mod(rr * q, p)
        hitP += (rr == 0); hit1 += (sub_mod(rr + 1, p) == 0); hit2 += (sub_mod(rr + 2, p) == 0); hit3 += (sub_mod(rr + 3, p) == 0)
    sf = int(min(factorint(Pk + 1).keys()))
    ok &= (hitP == k and hit1 == 0 and sf > ps[-1])
    rows.append((k, Pk, hitP, hit1, hit2, hit3, sf))
for r in rows: print("k=%2d  P=%d  山の数 P:%d  P+1:%d  P+2:%d  P+3:%d  P+1 の最小の素因数 %d" % r)
print("→", "OK" if ok else "NG")

print("== 検定E：メビウスの歩み M(x) は、x ≤ 10^7 で放物線 M² < x の内側にいるか")
N = 10 ** 7
mu = np.ones(N + 1, dtype=np.int8); mu[0] = 0
isc = np.zeros(N + 1, dtype=bool)
for p in range(2, N + 1):
    if p * p > N: break
    if not isc[p]:
        isc[p * p::p] = True
for p in np.nonzero(~isc[2:])[0] + 2:
    mu[p::p] *= -1
    if p * p <= N: mu[p * p::p * p] = 0
M = np.cumsum(mu.astype(np.int64))
x = np.arange(N + 1, dtype=np.int64)
out = np.nonzero(M[2:] * M[2:] >= x[2:])[0]
print("外に出た x の数:", len(out), "→", "OK" if len(out) == 0 else "NG")
i = int(np.argmax((M[2:] * M[2:]) * 10 ** 6 // x[2:])) + 2
print("いちばん放物線に近づいた x:", i, " M(x) =", int(M[i]), " M(x)^2 =", int(M[i]) ** 2, " x =", i)
lam = np.ones(N + 1, dtype=np.int8); lam[0] = 0           # 対照：平方因子を 0 にしない（素因数の個数を重複込みで数えた ±1）
for p in np.nonzero(~isc[2:])[0] + 2:
    q = p
    while q <= N: lam[q::q] *= -1; q *= p
L = np.cumsum(lam.astype(np.int64))
o2 = np.nonzero(L[2:] * L[2:] >= x[2:])[0]
mu3 = mu.copy(); mu3[3::3] = 0                                  # 対照：3 の倍数で歩みを止めずに 3 だけ数え落とす篩
chi = np.ones(N + 1, dtype=np.int64); chi[0] = 0
for p in np.nonzero(~isc[2:])[0] + 2:
    if p > 3: break
C = np.cumsum(np.where(np.arange(N + 1) % 3 == 0, 0, 1))      # 対照：3 の倍数を除いただけの数え上げ
o3 = np.nonzero(C[2:] * C[2:] >= x[2:])[0]
print("対照 平方因子を 0 にしない ±1 の歩み：外に出た x の数", len(o2), "（最初の x:", (int(o2[0]) + 2) if len(o2) else None, ")")
print("対照 3 の倍数だけを除いた数え上げ：外に出た x の数", len(o3), "→", "NG（期待どおり）" if len(o3) > 0 else "?")
np.save("M_small.npy", M[:2001])

print("== 検定B の対照：p − (5/p) の代わりにいつも p − 1 を使うと、割り切らない素数が出るか")
badc = 0
for p, alpha in ALPHA:
    t = p - 1
    while t > 0: t -= alpha
    badc += (t != 0)
print("割り切らない素数:", badc, "個 →", "NG（期待どおり）" if badc > 0 else "?")
