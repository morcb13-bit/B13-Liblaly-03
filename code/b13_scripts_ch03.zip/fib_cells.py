"""第3章の検定：(直前, 今) の盤で、フィボナッチ数の組だけを足し合わせて、すべてのマスに届くか。
フィボナッチ数の組 ＝ (0, 1) から歩いた輪の上のマス (F(n−1), F(n))。
マスどうしの足し算は、横・縦それぞれ足して m を越えたら m を引く。"""

def wrap(x, m):
    while x >= m: x -= m
    return x

def fib_cells(m):
    a, b, out = 0, 1, []
    while True:
        out.append((a, b))
        c = wrap(a + b, m); a, b = b, c
        if (a, b) == (0, 1): return out

def layers(m, gens):
    """何個のフィボナッチの組を足せば届くか。0 個＝(0,0)。"""
    reach = {(0, 0): 0}; front = [(0, 0)]; k = 0
    while front:
        k += 1; nxt = []
        for (x, y) in front:
            for (u, v) in gens:
                q = (wrap(x + u, m), wrap(y + v, m))
                if q not in reach:
                    reach[q] = k; nxt.append(q)
        front = nxt
    return reach

def mm(m):
    t = 0
    for _ in range(m): t += m
    return t

if __name__ == "__main__":
    print("== 検定12：フィボナッチの組だけを足して、盤のすべてのマスに届くか")
    for m in (7, 11, 13, 17):
        G = fib_cells(m)
        r = layers(m, G)
        cnt = {}
        for v in r.values(): cnt[v] = cnt.get(v, 0) + 1
        print(f"m={m:>2}  フィボナッチの組 {len(G):>2} マス  届いたマス {len(r)} / {mm(m)}  足した個数ごとのマス数 {dict(sorted(cnt.items()))}  {'OK' if len(r) == mm(m) else 'NG'}")
    bad = [m for m in range(2, 60) if len(layers(m, fib_cells(m))) != mm(m)]
    print("m = 2〜59 で届かないマスが残る盤:", bad, "→", "OK" if not bad else "NG")
    print("== 13 番地の盤で、歩いては止まらなかった番地 4, 6, 7, 9 を含むマスの例")
    G = fib_cells(13)
    for target in ((4, 6), (7, 9), (9, 4), (6, 7)):
        # 二つの組の和で書けるものを探す
        hit = [(g, h) for g in G for h in G if (wrap(g[0] + h[0], 13), wrap(g[1] + h[1], 13)) == target]
        print(target, "=", hit[0][0], "+", hit[0][1] if hit else "（二つでは届かない）")
    print("== 負の対照：(0, 2) から同じ足し算で歩いた輪だけを足して、12 番地の盤に落とす")
    def cells_from(a, b, m):
        out = []; a0, b0 = a, b
        while True:
            out.append((a, b)); c = wrap(a + b, m); a, b = b, c
            if (a, b) == (a0, b0): return out
    r = layers(12, cells_from(0, 2, 12))
    print("届いたマス", len(r), "/", mm(12), "（偶数の組しか作れない）")
