"""第3章 3.5 の検定：1 歩と 2 歩の歩幅で進む経路を、すべて数え上げて足し合わせる。
経路は一本ずつ数える（数えることと足し算だけ）。"""

def enumerate_paths(L, steps):
    """長さ（歩幅の合計）が L 以下の経路を、深さ優先で一本ずつ数える。count[n] = 合計 n で終わる経路の数"""
    count = [0] * (L + 1)
    stack = [0]
    while stack:
        n = stack.pop()
        count[n] += 1
        for s in steps:
            if n + s <= L: stack.append(n + s)
    return count

def fib_walk(L):
    out, a, b = [], 0, 1
    for _ in range(L + 2):
        out.append(a); a, b = b, a + b
    return out

def on_clock(count, m):
    """合計 n の経路を、m 番地の時計の番地 n に落として足し合わせる（m を越えたら m を引く）"""
    tot = [0] * m
    addr = 0
    for n, c in enumerate(count):
        tot[addr] += c
        addr += 1
        if addr >= m: addr -= m
    return tot

if __name__ == "__main__":
    L = 24
    cnt = enumerate_paths(L, (1, 2))
    F = fib_walk(L)
    print("== 検定8：合計 n で終わる経路の数（1 歩と 2 歩）")
    print("経路の数    :", cnt[:16], "…")
    print("フィボナッチ:", F[1:17], "…")
    ok = all(cnt[n] == F[n + 1] for n in range(L + 1))
    print("合計 n の経路の数 = F(n+1)（n = 0〜24）:", "OK" if ok else "NG")

    print("== 検定9：13 番地の時計に落とす")
    for LL in (12, 24):
        tot = on_clock(enumerate_paths(LL, (1, 2)), 13)
        print(f"合計 {LL} までの経路を落とした番地ごとの数:", tot)
        print("  届かない番地:", [x for x in range(13) if tot[x] == 0])
    tot = on_clock(cnt, 13)
    print("歩いて止まらなかった番地 4, 6, 7, 9 に届いた経路の数:", {x: tot[x] for x in (4, 6, 7, 9)})

    print("== 負の対照：歩幅を 2 歩と 4 歩にして、12 番地の時計に落とす")
    tot = on_clock(enumerate_paths(L, (2, 4)), 12)
    print("番地ごとの数:", tot, " 届かない番地:", [x for x in range(12) if tot[x] == 0])
