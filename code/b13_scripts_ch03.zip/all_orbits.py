"""第3章の検定：(直前, 今) の盤のすべての組から歩き出し、すべてのマスを辿れるか。
足して m を越えたら m を引くだけ。"""

def step(a, b, m):
    c = a + b
    if c >= m: c -= m
    return b, c

def orbits(m):
    seen = set(); out = []
    for a0 in range(m):
        for b0 in range(m):
            if (a0, b0) in seen: continue
            a, b, L = a0, b0, 0
            cyc = []
            while True:
                if (a, b) in seen:
                    return None              # 出発点以外のマスに戻った＝閉じない
                seen.add((a, b)); cyc.append((a, b))
                a, b = step(a, b, m); L += 1
                if (a, b) == (a0, b0): break
            out.append(L)
    return out

def primes_upto(N):
    mark = [False] * (N + 1); ps = []
    for p in range(2, N + 1):
        if not mark[p]:
            ps.append(p); q = p + p
            while q <= N: mark[q] = True; q += p
    return ps

if __name__ == "__main__":
    print("== 検定10：すべての組から歩き出すと、盤のすべてのマスを辿り、どの道も出発点に戻って閉じるか")
    for m in (7, 11, 13, 17):
        o = orbits(m)
        total = sum(o); mm = 0
        for _ in range(m): mm += m
        lens = {}
        for L in o: lens[L] = lens.get(L, 0) + 1
        print(f"m={m:>2}  輪の数 {len(o):>3}  長さごとの本数 {dict(sorted(lens.items()))}  辿ったマス {total} / {mm}  {'OK' if total == mm else 'NG'}")
    bad = []
    for m in range(2, 60):
        o = orbits(m)
        mm = 0
        for _ in range(m): mm += m
        if o is None or sum(o) != mm: bad.append(m)
    print("m = 2〜59 で辿り残しや閉じない道:", bad, "→", "OK" if not bad else "NG")
    print("== 負の対照：一歩を (a, b) → (b, b + b) に変えると（直前の数を使わず、今の数だけを足す）")
    def orbits_bad(m):
        seen = set(); n = 0
        for a0 in range(m):
            for b0 in range(m):
                a, b = a0, b0; path = set()
                while (a, b) not in path:
                    path.add((a, b)); c = b + b
                    if c >= m: c -= m
                    a, b = b, c
                if (a, b) != (a0, b0): n += 1
        return n
    print("13 番地の盤で、出発点に戻らない組:", orbits_bad(13), "個")

def fib_pairs(m, N):
    """(F(n−1), F(n)) を n = 0..N で（m を越えたら m を引く）。F(−1) = 1 から始める"""
    out = []; a, b = 1, 0
    for _ in range(N + 1):
        out.append((a, b)); c = a + b
        if c >= m: c -= m
        a, b = b, c
    return out

def times(k, x, m):
    t = 0
    for _ in range(k):
        t += x
        if t >= m: t -= m
    return t

if __name__ == "__main__":
    print("== 検定11：(a, b) から歩いた道の n 歩目は、a 個の (F(n−1), F(n)) と b 個の (F(n), F(n+1)) の和か")
    bad = 0; tot = 0
    for m in (7, 11, 13, 17):
        Fp = fib_pairs(m, 4 * m * m)
        for a0 in range(m):
            for b0 in range(m):
                a, b = a0, b0
                for n in range(2 * m):
                    p, q = Fp[n], Fp[n + 1]          # (F(n−1),F(n)) と (F(n),F(n+1))
                    x = times(a0, p[0], m) + times(b0, q[0], m)
                    y = times(a0, p[1], m) + times(b0, q[1], m)
                    if x >= m: x -= m
                    if y >= m: y -= m
                    tot += 1
                    if (x, y) != (a, b): bad += 1
                    a, b = step(a, b, m)
    print("照合したマス", tot, " 合わないマス", bad, "→", "OK" if bad == 0 else "NG")
    print("== 順に歩き出す：二つの 1 の組み合わせ a·(1,0) + b·(0,1) を (0,1),(0,2),…,(1,0),(1,1),… の順に取り、まだ辿っていなければ歩く")
    for m in (7, 11, 13, 17):
        seen = set(); starts = []
        for a0 in range(m):
            for b0 in range(m):
                if (a0, b0) in seen: continue
                starts.append((a0, b0))
                a, b = a0, b0
                while True:
                    seen.add((a, b)); a, b = step(a, b, m)
                    if (a, b) == (a0, b0): break
        print(f"m={m:>2}  歩き出した組 {len(starts):>2} 個 {starts[:8]}{' …' if len(starts) > 8 else ''}  辿ったマス {len(seen)} / {m*m}")
