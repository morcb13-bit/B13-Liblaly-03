"""第3章の検定：フィボナッチを m 番地の輪の上で歩かせ、周期と残りを読む。
番地は足して、m を越えたら m を引くだけ（割り算・剰余の演算子は使わない）。"""

def walk(m):
    """(直前, 今) の組が (0, 1) に戻るまで歩く。周期と、通った番地の集合を返す。"""
    a, b, n = 0, 1, 0
    seen = {0}
    while True:
        c = a + b
        if c >= m: c -= m            # 輪を一周したら m を引く
        a, b = b, c
        n += 1
        seen.add(a)
        if a == 0 and b == 1: return n, seen

def first_zero(m):
    a, b, n = 0, 1, 0
    while True:
        c = a + b
        if c >= m: c -= m
        a, b = b, c; n += 1
        if a == 0: return n

def zeros(m):
    """一周のあいだに 0 の番地を通る回数（数えるだけ）"""
    a, b, n, z = 0, 1, 0, 0
    while True:
        c = a + b
        if c >= m: c -= m
        a, b = b, c; n += 1
        if a == 0: z += 1
        if a == 0 and b == 1: return z

def reaches(step, target):           # step を足し重ねて target にちょうど届くか
    v = step
    while v < target: v += step
    return v == target

def primes_upto(N):
    mark = [False] * (N + 1); out = []
    for p in range(2, N + 1):
        if not mark[p]:
            out.append(p); q = p + p
            while q <= N: mark[q] = True; q += p
    return out

KNOWN = {2: 3, 3: 8, 4: 6, 5: 20, 6: 24, 7: 16, 8: 12, 9: 24, 10: 60, 11: 10, 12: 24, 13: 28}

if __name__ == "__main__":
    print("== 検定1：周期（2〜13 を知られている値と照合）")
    ok = True
    for m in range(2, 14):
        n, _ = walk(m); ok &= (n == KNOWN[m])
        print(f"m={m:>2}  周期 {n:>3}  知られている値 {KNOWN[m]:>3}")
    print("一致:", "OK" if ok else "NG")

    print("== 検定2：通らない番地と鏡（番地 x と m−x）、一周で 0 を何回通るか")
    for m in (5, 7, 11, 13, 17, 21, 29):
        n, seen = walk(m)
        miss = [x for x in range(m) if x not in seen]
        mirror = all((m - x) in miss for x in miss if x)
        print(f"m={m:>2}  周期 {n:>3}  0 を通る回数 {zeros(m)}  通らない番地 {miss}  鏡で閉じる {'OK' if mirror else 'NG'}")
    tally = {}
    for p in primes_upto(400):
        if p in (2, 5): continue
        n, seen = walk(p)
        miss = [x for x in range(p) if x not in seen]
        mirror = all((p - x) in miss for x in miss if x)
        key = (zeros(p), mirror)
        tally[key] = tally.get(key, 0) + 1
    print("400 までの素数（2・5 を除く）の内訳 (0 を通る回数, 鏡で閉じるか):", dict(sorted(tally.items())))
    good = all((z >= 2) == mir for (z, mir) in tally)
    print("鏡で閉じる ⇔ 0 を 2 回以上通る:", "OK" if good else "NG")

    print("== 検定3：最後の桁で周期の届き先が決まる（100 までの素数、5 を除く）")
    r1, r2, bad = 0, 0, []
    for p in primes_upto(100):
        if p in (2, 5): continue
        n, _ = walk(p); last = str(p)[-1]          # 最後の桁は観察者側の読み
        if last in "19":
            r1 += 1
            if not reaches(n, p - 1): bad.append(p)
        else:
            r2 += 1
            if not reaches(n, (p + 1) + (p + 1)): bad.append(p)
    print(f"最後の桁 1・9 の素数 {r1} 個：周期を足し重ねて p−1 に届く")
    print(f"最後の桁 3・7 の素数 {r2} 個：周期を足し重ねて 2(p+1) に届く")
    print("届かない素数:", bad, "→", "OK" if not bad else "NG")
    # 負の対照：届き先を入れ替える
    swap = [p for p in primes_upto(100) if p not in (2, 5) and
            not reaches(walk(p)[0], (p - 1) if str(p)[-1] in "37" else (p + 1) + (p + 1))]
    print("対照（届き先を入れ替える）で届かない素数:", len(swap), "個")

    print("== 検定4：13 の塔")
    for k, m in ((1, 13), (2, 169), (3, 2197), (4, 28561)):
        n, _ = walk(m)
        want = 28
        for _ in range(k - 1):
            w = 0
            for _ in range(13): w += want
            want = w
        print(f"13^{k} = {m:>5}  周期 {n:>6}  28×13^(k−1) = {want:>6}  {'OK' if n == want else 'NG'}")

    print("== 検定5：p×p の輪で周期は p 倍になるか（200 までの素数）")
    same = []
    for p in primes_upto(200):
        n1, _ = walk(p)
        m2 = 0
        for _ in range(p): m2 += p          # p×p も足し算で
        n2, _ = walk(m2)
        w = 0
        for _ in range(p): w += n1
        if n2 != w: same.append((p, n1, n2))
    print("p 倍にならない素数:", same, "→", "OK（例外なし）" if not same else "例外あり")
