"""第3章 3.5 の検定：残した札（フィボナッチ数）の組み合わせで、全部の番地に届くか。
引いていくことと数えることだけを使う。"""

def slots(limit, a=1, b=2, rule="fib"):
    """札を作る。fib：1, 2, 3, 5, 8, …（前の二つを足す）／double：1, 2, 4, 8, …（自分を足す）"""
    out = [a]
    x, y = a, b
    while y <= limit:
        out.append(y)
        x, y = (y, x + y) if rule == "fib" else (y, y + y)
    return out

def greedy(n, S):
    """大きい札から順に、引ける札を引いていく。使った札の番号（小さい方から）を返す。"""
    used = []
    i = len(S) - 1
    while n > 0 and i >= 0:
        if S[i] <= n:
            n -= S[i]; used.append(i)
        i -= 1
    return (sorted(used) if n == 0 else None)

def non_adjacent(idx):
    return all(idx[k + 1] - idx[k] >= 2 for k in range(len(idx) - 1))

if __name__ == "__main__":
    N = 10000
    F = slots(N)
    print("札:", F)

    print("== 検定6：1〜10000 を、大きい札から引いていくだけで分解できるか")
    bad = [n for n in range(1, N + 1) if greedy(n, F) is None]
    adj = [n for n in range(1, N + 1) if greedy(n, F) is not None and not non_adjacent(greedy(n, F))]
    print("届かない数:", len(bad), " 隣り合う札を使った数:", len(adj), "→", "OK" if not bad and not adj else "NG")

    print("== 検定7：書き方は一通りか（札 1〜987 の、隣り合わない選び方をすべて数える）")
    S = slots(987)
    count = {}
    def rec(i, total):
        if i >= len(S):
            count[total] = count.get(total, 0) + 1; return
        rec(i + 1, total)               # i 番の札を使わない
        rec(i + 2, total + S[i])        # i 番の札を使う（次の札は飛ばす）
    rec(0, 0)
    top = max(count)
    print(f"選び方の数 {sum(count.values())}  和の範囲 0〜{top}  抜けた和 {sum(1 for t in range(top + 1) if t not in count)}  二通り以上の和 {sum(1 for c in count.values() if c > 1)}")
    print("→", "OK" if all(count.get(t) == 1 for t in range(top + 1)) else "NG")

    print("== 13 番地の時計で止まらなかった番地")
    for n in (4, 6, 7, 9):
        print(f"{n} = " + " + ".join(str(F[i]) for i in reversed(greedy(n, F))))

    print("== 負の対照：札を倍々（1, 2, 4, 8, …）にし、隣り合わない札だけで足す")
    D = slots(N, 1, 2, "double")
    miss = []
    for n in range(1, 101):
        g = greedy(n, D)
        if g is None or not non_adjacent(g): miss.append(n)
    print("札:", D[:8], "…  100 までで届かない数:", len(miss), miss[:10], "→", "NG（期待どおり）" if miss else "OK")
