"""第6章の図のデータ。級数の部分和（整数の分子・分母で持つ）と、ハウプトモジュール t_2A の q 展開（整数の冪級数の足し算と掛け算）。
小数への換算（π の桁・e^{π√N}）は観察者側の表示のために mpmath で行う。"""
import json
from fractions import Fraction
from math import factorial
import mpmath as mp
mp.mp.dps = 80
PI = str(mp.pi)[:62]

def digits_ok(x, ref):
    s = mp.nstr(x, 60, strip_zeros=False); n = 0
    while n < len(s) and n < len(ref) and s[n] == ref[n]: n += 1
    return s, n

def series58(a, b, terms):
    S = Fraction(0); out = []
    for n in range(terms):
        S += Fraction(factorial(4 * n) * (a + b * n), factorial(n) ** 4 * 396 ** (4 * n))
        pi_n = mp.mpf(9801) / (2 * mp.sqrt(2) * mp.mpf(S.numerator) / S.denominator)
        out.append(digits_ok(pi_n, PI))
    return out

def series37(a, b, terms):
    S = Fraction(0); out = []
    for n in range(terms):
        S += Fraction((-1) ** n * factorial(4 * n) * (a + b * n), 882 ** (2 * n + 1) * (4 ** n * factorial(n)) ** 4)
        pi_n = 4 / (mp.mpf(S.numerator) / S.denominator)
        out.append(digits_ok(pi_n, PI))
    return out

fig1 = {"pi": PI,
        "s58": series58(1103, 26390, 7), "s58c": series58(1104, 26390, 7),
        "s37": series37(1123, 21460, 9), "s37c": series37(1124, 21460, 9)}

# ---- q 展開（整数の冪級数）
M = 8
def mul(A, B):
    C = [0] * M
    for i in range(M):
        if A[i] == 0: continue
        for j in range(M - i): C[i + j] += A[i] * B[j]
    return C
def prod_pow(e):            # ∏(1 + q^n)^e を q^0..q^{M-1} まで（e は正）
    P = [1] + [0] * (M - 1)
    for n in range(1, M):
        f = [0] * M; f[0] = 1; f[n] = 1
        for _ in range(e): P = mul(P, f)
    return P
def inv(A):                 # 定数項 1 の冪級数の逆数（引き算と掛け算だけ）
    B = [0] * M; B[0] = 1
    for k in range(1, M): B[k] = -sum(A[i] * B[k - i] for i in range(1, k + 1))
    return B
def t2A(e=24):
    P = prod_pow(e); Q = inv(P)
    # t = q^{-1} Q + 128 + 4096 q P  を q^{-1}, q^0, q^1, ... の係数で
    c = [0] * (M + 1)
    for k in range(M): c[k] += Q[k]          # q^{k-1}
    c[1] += 128
    for k in range(M - 1): c[k + 2] += 4096 * P[k]
    return c[:M]
coef = t2A(24); ctrl = t2A(23)
print("t_2A の係数 (q^-1, q^0, q^1, ...):", coef)
print("対照（指数 23）:", ctrl)

pts = {}
for N, t_int in ((22, 2509056), (25, -6635520), (37, -199148544), (58, 24591257856)):
    q = mp.e ** (-mp.pi * mp.sqrt(N)) * (1 if t_int > 0 else -1)
    partial = []; s = mp.mpf(0)
    for k, ck in enumerate(coef[:6]):
        s += ck * q ** (k - 1)
        partial.append(mp.nstr(s, 30, strip_zeros=False))
    pts[N] = {"t": t_int, "q": mp.nstr(q, 12), "partial": partial,
              "terms": [mp.nstr(ck * q ** (k - 1), 12) for k, ck in enumerate(coef[:6])],
              "x": mp.nstr(mp.pi * mp.sqrt(N), 15)}
    print(N, t_int, partial[:4])
fig2 = {"coef": coef[:6], "pts": pts}
json.dump({"fig1": fig1, "fig2": fig2}, open("ramanujan_figs.json", "w"), ensure_ascii=False, indent=1)
for k in ("s58", "s58c", "s37", "s37c"): print(k, [d for _, d in fig1[k]])
