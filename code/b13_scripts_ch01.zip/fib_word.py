"""第1章の検定：フィボナッチの二つの 1（b と a）から、つなぐことだけで列を育てる。
S1 = "b", S2 = "a", S(n) = S(n-1) + S(n-2)（文字列をつなぐ＝足し算）。
数えることと足し算だけを使い、割り算・小数・φ は使わない。"""

def grow(rule, n_max):
    S = {1: "b", 2: "a"}
    for n in range(3, n_max + 1):
        S[n] = rule(S, n)
    return S

def positions(word):
    A, B, k = [], [], 0
    for ch in word:
        k += 1
        (A if ch == "a" else B).append(k)
    return A, B

def check(word, label):
    A, B = positions(word)
    m = min(len(A), len(B))
    # 検定1：b の n 番目の番地 = a の n 番目の番地 + n
    t1 = all(B[i] == A[i] + (i + 1) for i in range(m))
    # 検定2：a の (a の n 番目) 番目の番地 + 1 = b の n 番目の番地
    lim = [i for i in range(m) if A[i] <= len(A)]
    t2 = all(A[A[i] - 1] + 1 == B[i] for i in lim)
    print(f"{label}: 長さ {len(word)}  a {len(A)} 個  b {len(B)} 個  検定1 {'OK' if t1 else 'NG'}  検定2 {'OK' if t2 else 'NG'}")
    return A, B, t1, t2

if __name__ == "__main__":
    S = grow(lambda S, n: S[n-1] + S[n-2], 25)
    print("== 育ち方")
    for n in range(1, 10):
        A, B = positions(S[n])
        print(f"S{n:<2} {S[n]:<34} 長さ {len(S[n]):>2}  a {len(A):>2}  b {len(B):>2}")
    print("== 番地の二つの列（S9 の中）")
    A, B = positions(S[9])
    print("a の番地:", A)
    print("b の番地:", B)
    print("== 検定")
    check(S[25], "本番   S(n)=S(n-1)+S(n-2), n=25")
    # 負の対照：つなぎ方を変える
    N1 = grow(lambda S, n: S[n-1] + S[n-3] if n > 3 else S[n-1] + S[n-2], 30)
    check(N1[30], "対照1  S(n)=S(n-1)+S(n-3), n=30")
    N2 = grow(lambda S, n: S[n-2] + S[n-1], 25)
    check(N2[25], "対照2  つなぐ順を逆 S(n)=S(n-2)+S(n-1)")
    print("== 二つの 1 の番地（直前の数, 今の数）")
    p, c = 0, 1
    walk = []
    for _ in range(8):
        walk.append((p, c)); p, c = c, p + c
    print("前へ:", walk)
    p, c = 0, 1
    back = []
    for _ in range(8):
        back.append((p, c)); p, c = c - p, p
    print("後ろへ:", back)
