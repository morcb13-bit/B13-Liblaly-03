"""第1章 1.x の検定：二つの 1 の残渣。
数 p + qφ を整数の組 (p, q) で持つ。残渣の側は p + qψ ＝ (p + q) − qφ（ψ は φ の共役）。
符号の判定は b13_chain_units.phi_sign（整数の比べ合いだけ）を使う。φ・小数は使わない。"""
from b13_chain_units import phi_sign

def res(p, q):            # 残渣の側を (定数, φ の係数) で
    return (p + q, -q)

def sign(x): return phi_sign(x)
def sub(x, y): return (x[0] - y[0], x[1] - y[1])
def neg(x): return (-x[0], -x[1])
def absv(x): return x if sign(x) >= 0 else neg(x)

if __name__ == "__main__":
    print("== 検定R1：(直前, 今) = (F(n−1), F(n)) を数 F(n−1) + F(n)φ と読むと、残渣の側は符号を交互に裏返しながら縮むか（n = 1〜60）")
    a, b = 0, 1                       # n = 1：(0, 1)。二つ目の 1 は n = 2：(1, 1)
    prev = None; alt = True; shrink = True; signs = []
    want = -1
    for n in range(1, 61):
        r = res(a, b); s = sign(r); signs.append(s)
        alt &= (s == want); want = -want
        if prev is not None: shrink &= sign(sub(absv(prev), absv(r))) > 0
        prev = r
        a, b = b, a + b
    print("残渣の符号（n = 1〜12）:", signs[:12])
    print("符号が交互:", "OK" if alt else "NG", " 大きさが一歩ごとに縮む:", "OK" if shrink else "NG")
    print("一つ目の 1 (0, 1) の残渣:", res(0, 1), "＝ 0 − 1·φ + 1 … 符号", sign(res(0, 1)),
          "　二つ目の 1 (1, 1) の残渣:", res(1, 1), "… 符号", sign(res(1, 1)))

    print("== 検定R2：実の側 × 残渣の側 ＝ p·p + p·q − q·q は +1 と −1 を交互にくり返すか（第4章の Q と同じ）")
    a, b = 0, 1; out = []; ok = True; want = -1
    for n in range(1, 61):
        N = a * a + a * b - b * b
        out.append(N); ok &= (N == want); want = -want
        a, b = b, a + b
    print("最初の 10 個:", out[:10], "→", "OK" if ok else "NG")
    for name, a, b in [("対照：(2, 1) から（リュカの道）", 2, 1), ("対照：(1, 2) から一つずつ数える (n, n+1)", 1, 2)]:
        out = []
        for n in range(10):
            out.append(a * a + a * b - b * b)
            a, b = (b, a + b) if "リュカ" in name else (a + 1, b + 1)
        print(name, out, "→ ±1 の交互:", "OK" if all(out[i] == (-1 if i % 2 == 0 else 1) for i in range(10)) else "NG（期待どおり）")

    print("== 検定R3：残渣の時計（長さ 1 の輪。出発 2 − φ、一歩 2 − φ ＝ 二つ目の 1 の残渣）が、1.2 の札の列を書くか")
    S = {1: "b", 2: "a"}
    for k in range(3, 20): S[k] = S[k - 1] + S[k - 2]
    word = S[19][:2000]
    def clock(start, step, n):
        r = start; out = []
        for k in range(n):
            r = (r[0] + step[0], r[1] + step[1])
            if sign(sub(r, (1, 0))) >= 0:   # 1 を越えたら 1 を引いて輪に戻す
                r = sub(r, (1, 0)); out.append("b")
            else:
                out.append("a")
        return "".join(out)
    w = clock((2, -1), (2, -1), 2000)
    print("時計の書く列:", w[:21]); print("札の列 S    :", word[:21])
    print("2000 文字すべて一致:", "OK" if w == word else "NG")
    t = 5; out = []
    for k in range(2000):
        t += 5
        if t >= 13: t -= 13; out.append("b")
        else: out.append("a")
    c = "".join(out); n = 0
    while n < 2000 and c[n] == word[n]: n += 1
    print("対照：一歩 5/13 の時計:", c[:21], "→ 一致", "NG（期待どおり）" if c != word else "OK", "／ 最初に食い違う番地", n + 1)

    print("== 検定R4：R3 の残渣の時計は出発点に戻らないか（10000 歩）。対照：一歩を 5/13 にした時計は戻る")
    r = (2, -1); back = 0
    for k in range(1, 10001):
        r = (r[0] + 2, r[1] - 1)
        if sign(sub(r, (1, 0))) >= 0: r = sub(r, (1, 0))
        if r == (2, -1): back += 1
    print("残渣の時計が出発点に戻った回数:", back, "→", "OK（戻らない）" if back == 0 else "NG")
    t = 5; first = None
    for k in range(1, 100):
        t += 5
        if t >= 13: t -= 13          # 13 等分の輪で 5 ずつ（一歩 5/13）
        if t == 5: first = k; break
    print("5/13 の時計が出発点に戻る歩数:", first)
