"""第9章の検定：BSD 予想。番地 p の盤の上で、曲線に着地する点を数える。
検定1〜3 は整数の足し算と比べ合いだけ（掛け算は小さな整数どうし、余りは引き戻し）。
検定4 の傾き（対数）は観察者側の小数。点の数そのものは整数で数える。"""
import json, math
import numpy as np

def primes_upto(n):
    c = bytearray(n + 1); c[0] = c[1] = 1
    for p in range(2, int(n ** .5) + 1):
        if not c[p]:
            v = p * p
            while v <= n: c[v] = 1; v += p
    return [i for i in range(n + 1) if not c[i]]

def board_count(p, f):
    """盤 p×p のマスのうち f(x, y) が p の倍数になるものを数える。f の値は足し算で作り、引き戻しは引き算。"""
    n = 0
    for x in range(p):
        for y in range(p):
            v = f(x, y)
            while v < 0: v += p
            while v >= p: v -= p
            n += (v == 0)
    return n

print("== 検定1：一段目（フィボナッチの双曲線 x² − xy − y² = 1）は、どの番地でも着地の数が p ± 1 ちょうどか")
ok = True; ex = []
for p in primes_upto(150):
    if p in (2, 5): continue
    N = board_count(p, lambda x, y: x * x - x * y - y * y - 1)
    r = p; 
    while r >= 5: r -= 5
    want = p - 1 if r in (1, 4) else p + 1
    ok &= (N == want); ex.append((p, N))
print("例:", ex[:8], "→", "OK" if ok else "NG")
print("   対照：右辺を x² − xy − y² の代わりに x² − y² − 2 にすると（別の二次曲線）、p ± 1 の決まり（5 で引き戻した余り）に従わない番地が出るか")
bad = 0
for p in primes_upto(150):
    if p in (2, 5): continue
    N = board_count(p, lambda x, y: x * x - y * y - 2)
    r = p
    while r >= 5: r -= 5
    bad += (N != (p - 1 if r in (1, 4) else p + 1))
print("   決まりに従わない番地:", bad, "→", "NG（期待どおり）" if bad > 0 else "?")

print("== 検定2：二段目 y² = x³ − 3x + b を番地 13 で九段回す（射影的な非特異点の数）")
p = 13; rows = []
for b in range(-4, 5):
    pts = [(x, y) for x in range(p) for y in range(p) if (y * y - (x ** 3 - 3 * x + b)) % p == 0]
    sing = [(x, y) for (x, y) in pts if (2 * y) % p == 0 and (3 * x * x - 3) % p == 0]
    N = len(pts) + 1 - len(sing)
    rows.append((b, N, None if sing else p + 1 - N, len(sing)))
print("b, N, 残渣 a, 特異点:", rows)
okN = [r[1] for r in rows] == [15, 16, 12, 19, 8, 19, 12, 16, 15]
print("→", "OK（前の記事の表と一致、特異点は b = ±2 だけで N = 12 = p − 1）" if okN and [r[0] for r in rows if r[3]] == [-2, 2] else "NG")

print("== 検定3：−1 が着地しない番地（7, 11）では、N(b) + N(−b) = 2(p + 1) になるか（滑らかな段）")
for p in (7, 11, 13, 17):
    s = []
    for b in range(1, 5):
        def N_(bb):
            pts = [(x, y) for x in range(p) for y in range(p) if (y * y - (x ** 3 - 3 * x + bb)) % p == 0]
            sing = [(x, y) for (x, y) in pts if (2 * y) % p == 0 and (3 * x * x - 3) % p == 0]
            return len(pts) + 1 - len(sing), len(sing)
        (n1, s1), (n2, s2) = N_(b), N_(-b)
        s.append((b, n1, n2, n1 + n2, "特異" if s1 or s2 else ""))
    print("  p =", p, s)

print("== 検定4：台帳。∏ N_p / p の対数を log log X に対して描いた傾き（p ≥ 100 の最小二乗）が、階数 r に並ぶか（X = 10^5）")
CURVES = {  # 名前: (r, 点の数を数える関数の係数, 悪い番地)
    "y²=x³−x": (0, ("w", 0, -1, 0), {2}),
    "y²=x³−36x": (1, ("w", 0, -36, 0), {2, 3}),
    "389a": (2, ("u", 1, -2, 0), {389}),          # y² + y = x³ + x² − 2x
    "5077a": (3, ("u", 0, -7, 6), {5077}),       # y² + y = x³ − 7x + 6
}
X = 100000
P = [p for p in primes_upto(X) if p > 3]
def count(p, spec):
    kind, A2, A4, A6 = spec
    x = np.arange(p, dtype=np.int64)
    if kind == "w": rhs = (x * x % p * x + A4 * x + A6) % p                 # y² = x³ + A4 x + A6
    else: rhs = (4 * (x * x % p * x + A2 * x * x + A4 * x + A6) + 1) % p    # (2y+1)² = 4(x³+A2x²+A4x+A6)+1
    sq = np.zeros(p, dtype=np.int64); sq[(x * x) % p] += 1
    nsq = np.bincount((x * x) % p, minlength=p)                              # y² ＝ v となる y の個数
    return int(nsq[rhs].sum()) + 1
data = {}; slopes = {}
for name, (r, spec, bad) in CURVES.items():
    lg = 0.0; xs = []; ys = []; ap = []
    for p in P:
        if p in bad: continue
        N = count(p, spec); ap.append((p, p + 1 - N))
        lg += math.log(N / p)
        xs.append(math.log(math.log(p))); ys.append(lg)
    k = next(i for i, pp in enumerate(q for q in P if q not in bad) if pp >= 100)
    def lsq(X_, Y_):                      # 最小二乗の傾き（観察者側の小数）
        n = len(X_); mx = sum(X_) / n; my = sum(Y_) / n
        return sum((a - mx) * (b - my) for a, b in zip(X_, Y_)) / sum((a - mx) ** 2 for a in X_)
    sl = lsq(xs[k:], ys[k:])
    slopes[name] = (r, round(sl, 2))
    sel = list(range(0, len(xs), max(1, len(xs) // 300)))
    data[name] = {"r": r, "x": [round(xs[i], 4) for i in sel], "y": [round(ys[i], 4) for i in sel]}
    # 対照：残渣の符号を、番地の並びで交互に入れ替える
    lg2 = 0.0; ys2 = []; s = 1
    for (p, a) in ap:
        lg2 += math.log((p + 1 - s * a) / p); ys2.append(lg2); s = -s
    sl2 = lsq(xs[k:], ys2[k:])
    data[name]["yc"] = [round(ys2[i], 4) for i in sel]
    print("  %-10s 階数 %d  傾き %+.2f   対照（残渣の符号を交互に入れ替え）%+.2f" % (name, r, sl, sl2))
ok = all(abs(v[1] - v[0]) < 0.3 for k, v in slopes.items() if v[0] <= 2)
print("→ 階数 0, 1, 2 で傾きが階数から 0.3 以内:", "OK" if ok else "NG", "／ 階数 3 の傾き", slopes["5077a"][1])
json.dump(data, open("bsd_ledger.json", "w"))
