"""第8章の検定：エルデシュ問題 #346 と Graham の列。整数と足し算・比べ合いだけ。
相異なる項の和で届く数は、整数を一本のビット列に見立て、項を足すたびに「ずらして重ねる」だけで求める。
数 N に届くかどうかは N 以下の項だけで決まるので、窓（どこまで見るか）を U とすれば、U 以下の判定は窓の端の影響を受けない。"""
F = [0, 1]
for i in range(70): F.append(F[-1] + F[-2])

def last_hole(terms, U):
    """U 以下で、相異なる項の和で届かない最大の数（なければ 0）。"""
    R = 1
    for t in terms:
        if t <= U: R = R | (R << t)
    s = bin((R & ((1 << (U + 1)) - 1)) | (1 << (U + 1)))[3:]   # 上の桁から順に、届く 1 ／届かない 0
    i = s.find("0")
    return U - i if i >= 0 else 0

WINDOWS = (10 ** 6, 10 ** 7, 10 ** 8)
def tails(seq, name, drops):
    print(name, "  最初の項:", seq[:10])
    res = []
    for d in drops:
        hs = [last_hole(seq[d:], U) for U in WINDOWS]
        done = (hs[0] == hs[1] == hs[2]) and hs[0] < WINDOWS[0]
        res.append((d, hs, done))
        print("  先頭を %d 項落とした尾：最後の穴（窓 10^6, 10^7, 10^8）= %s → %s" % (d, hs, "穴が尽きる" if done else "窓を広げても穴が端まで残る"))
    return res

fib = [F[k] for k in range(1, 60)]
gra = sorted(v for v in (F[k] - (-1) ** k for k in range(1, 60)) if v > 0)
plus1 = sorted(F[k] + 1 for k in range(1, 60))
minus1 = sorted(v for v in (F[k] - 1 for k in range(1, 60)) if v > 0)

print("== 検定1：素のフィボナッチ列は、先頭を 2 項落とすと穴が尽きなくなるか")
r = tails(fib, "フィボナッチ", range(0, 5))
print("→", "OK" if r[0][2] and r[1][2] and not any(x[2] for x in r[2:]) else "NG")

print("== 検定2：Graham の列 F(k) − (−1)^k は、先頭を何項落としても穴が尽きるか（尾 0〜4）")
r = tails(gra, "Graham の列", range(0, 5))
print("→", "OK" if all(x[2] for x in r) else "NG")
print("   尾 5 から先は、穴の尽きる所が窓 10^8 より先にあり、この窓では測れない")

print("== 検定3：残渣の ±1：f(j) + f(j+1) − f(j+2) = (−1)^j と、F(j+1)² − F(j+1)F(j) − F(j)² = (−1)^j")
ok = True
for j in range(1, 60):
    f = lambda k: F[k] - (-1) ** k
    ok &= (f(j) + f(j + 1) - f(j + 2) == (-1) ** j) and (F[j + 1] ** 2 - F[j + 1] * F[j] - F[j] ** 2 == (-1) ** j)
print("j = 1〜59 →", "OK" if ok else "NG")

print("== 検定4（対照）：±1 を交互にせず、いつも +1（F(k) + 1）・いつも −1（F(k) − 1）にした列")
for name, s in (("F(k) + 1", plus1), ("F(k) − 1", minus1)):
    r = tails(s, "  " + name, range(0, 5))
    print("  →", "穴が尽きない尾がある（期待どおり）" if not all(x[2] for x in r) else "どの尾でも穴が尽きる")

print("== 検定5：Graham の列の比は φ の両側を交互に渡るか（x² − xy − y² の符号、x = f(k+1), y = f(k)）")
g = [F[k] - (-1) ** k for k in range(5, 40)]
sg = [(1 if v > 0 else -1) for v in (g[i + 1] ** 2 - g[i + 1] * g[i] - g[i] ** 2 for i in range(len(g) - 1))]
alt = all(sg[i] == -sg[i + 1] for i in range(len(sg) - 1))
print("符号:", sg[:12], "→", "交互 OK" if alt else "NG")

print("== 追加の測定：検定2 の尾 4 を、窓 10^8 と 3×10^8 で比べる")
h = [last_hole(gra[4:], U) for U in (10 ** 8, 3 * 10 ** 8)]
print("  最後の穴:", h, "→", "二つの窓で同じ（穴は 12080990 で尽きる）" if h[0] == h[1] else "まだ動く")
