"""第5章の検定：双子素数。整数と足し算・引き算・比べ合いだけを使う（割り算・剰余・小数は使わない）。"""
N = 1000000

def prime_marks(n):
    """エラトステネスの篩：足し算で歩いて印をつける。"""
    comp = bytearray(n + 1); comp[0] = comp[1] = 1
    p = 2
    while p * p <= n:
        if not comp[p]:
            v = p * p
            while v <= n: comp[v] = 1; v += p
        p += 1
    return comp

comp = prime_marks(N + 2)
def isp(m): return comp[m] == 0

# ---- 検定1：間が 2 の素数の組は、(3, 5) を除いて軸 6k の両隣にあるか
pairs = [(p, p + 2) for p in range(2, N - 1) if isp(p) and isp(p + 2)]
six = bytearray(N + 3); v = 0
while v <= N + 2: six[v] = 1; v += 6           # 6 の倍数の印も足し算で
off = [pr for pr in pairs if not six[pr[0] + 1]]
print("== 検定1")
print("100万までの間が 2 の素数の組:", len(pairs), "組  真ん中が 6 の倍数でない組:", off)
print("→", "OK" if off == [(3, 5)] else "NG")
cous = [(p, p + 4) for p in range(2, N - 3) if isp(p) and isp(p + 4)]
cous_on = [c for c in cous if six[c[0] + 2]]
print("対照：間が 4 の組", len(cous), "組のうち、真ん中が 6 の倍数の組:", len(cous_on), "→ 6k の軸の両隣という形:", "OK" if len(cous_on) == len(cous) else "NG（期待どおり）")

# ---- 検定2：軸 k（6k ± 1）を、各 p が二か所ずつ打つ篩
K = 0
while 6 * (K + 1) + 1 <= N: K += 1              # 6K + 1 ≤ N となる最大の K
small = [p for p in range(5, 1001) if isp(p)]   # p × p ≤ 6K + 1 の範囲で足りる
def start(p, sgn):
    """6k + sgn が p の倍数になる最小の k ≥ 1 を、足し算と引き算だけで探す。"""
    k = 1; r = 6 + sgn                          # r ＝ 6k + sgn を p で引き戻した余り
    while r >= p: r -= p
    while r < 0: r += p
    while r != 0:
        k += 1; r += 6
        while r >= p: r -= p
    return k
def axis_sieve(two):
    hit = bytearray(K + 1)
    for p in small:
        if p * p > 6 * K + 1: break
        for sgn in ((-1, 1) if two else (-1,)):
            k = start(p, sgn)
            if 6 * k + sgn == p: k += p          # p 自身は打たない
            while k <= K: hit[k] = 1; k += p
    return sum(1 for k in range(1, K + 1) if not hit[k])
direct = sum(1 for k in range(1, K + 1) if isp(6 * k - 1) and isp(6 * k + 1))
two = axis_sieve(True); one = axis_sieve(False)
print("== 検定2")
print("軸の数 K =", K, " 直接数えた双子（真ん中 6k）:", direct, " 二か所を打つ篩の残り:", two, "→", "OK" if two == direct else "NG")
print("対照：一か所だけ打つ篩の残り:", one, "→", "一致 OK" if one == direct else "NG（期待どおり）")

# ---- 検定3：5・7・11・13 の輪を重ねた一周 5005 軸で、残る軸の数
L = 5 * 7 * 11 * 13
def ring_count(two):
    hit = bytearray(L + 1)
    for p in (5, 7, 11, 13):
        for sgn in ((-1, 1) if two else (-1,)):
            k = start(p, sgn)
            while k <= L: hit[k] = 1; k += p
    return sum(1 for k in range(1, L + 1) if not hit[k])
r2 = ring_count(True); r1 = ring_count(False)
print("== 検定3")
print("一周", L, "軸のうち、二か所を打つ篩で残る軸:", r2, " 期待 3×5×9×11 =", 3 * 5 * 9 * 11, "→", "OK" if r2 == 3 * 5 * 9 * 11 else "NG")
print("対照：一か所だけ打つ篩で残る軸:", r1, " 期待 4×6×10×12 =", 4 * 6 * 10 * 12, "→", "OK" if r1 == 4 * 6 * 10 * 12 else "NG")

# ---- 参考：範囲ごとの双子の数（(3, 5) を含む）
print("== 参考")
for M in (100, 1000, 10000, 100000, 1000000):
    print(M, "までの双子:", sum(1 for p, q in pairs if q <= M), "組")
