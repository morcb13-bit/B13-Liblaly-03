"""第4章の検定：篩を波の重ね合わせとして見る。整数と足し算だけ。"""
import b13_chain_units as B

def wave_sieve(N):
    """選ぶ数 s を見つけるたびに、周期 s の波（s, s+s, s+s+s, … に山）を一本足す。
    s は「まだどの波の山にも当たっていない、いちばん小さい数」。"""
    hits = [0] * (N + 1)
    waves = []
    n = 2
    while n <= N:
        if hits[n] == 0:                 # どの波も鳴らない ⇒ 新しい波を立てる
            waves.append(n)
            v = n
            while v <= N:
                hits[v] += 1; v += n
        n += 1
    return waves, hits

def by_trial(N):
    out = []
    for n in range(2, N + 1):
        ok = True; d = 2
        while d + d <= n and ok:
            v = d + d
            while v < n: v += d
            if v == n: ok = False
            d += 1
        if ok: out.append(n)
    return out

def ring_walk(p, n):
    """p 番地の輪を n ずつ p 回進む。戻った番地の数え上げを返す。"""
    cnt = [0] * p; a = 0
    step = n
    while step >= p: step -= p
    for _ in range(p):
        cnt[a] += 1
        a += step
        if a >= p: a -= p
    return cnt

if __name__ == "__main__":
    N = 100
    waves, hits = wave_sieve(N)
    print("== 検定1：波を立てながら重ねる（1〜100）")
    print("立った波の周期:", waves)
    print("山が一つだけの数（素数と、4・8・9 のような素数のべき）:", [n for n in range(2, N + 1) if hits[n] == 1])
    print("立った波 = 別の方法で確かめた素数:", "OK" if waves == by_trial(N) else "NG")
    print("山の数ごとの数（2〜100）:", {k: sum(1 for n in range(2, N + 1) if hits[n] == k) for k in sorted(set(hits[2:]))})
    print("例 30 に重なる山:", [p for p in waves if any(v == 30 for v in range(p, 31, p))])

    print("== 検定2：波が打ち消し合う骨組み（p 番地の輪を n ずつ p 回進む）")
    bad = []
    for p in by_trial(47):
        for n in range(1, 201):
            c = ring_walk(p, n)
            t = n
            while t >= p: t -= p
            mult = t == 0                         # p を引き続けて 0 になれば p の倍数
            if mult and c != [p] + [0] * (p - 1): bad.append((p, n))
            if not mult and c != [1] * p: bad.append((p, n))
    print("47 までの素数 p、n = 1〜200：p の倍数なら番地 0 に p 回、そうでなければ全番地に 1 回ずつ →", "OK" if not bad else f"NG {bad[:5]}")

    print("== 検定3：ペンローズの鎖を波として見る（Z[ζ] の整数 4 つの組で比べる）")
    odd = [B.zsub(B.unit(9)[i + 1], B.unit(9)[i]) for i in range(8)]
    alt = odd == [B.C_A, B.C_B] * 4
    print("奇数の鎖の一歩は二つの向きを交互にくり返す（山と谷）:", "OK" if alt else "NG")
    mirror = B.zmul(B.zconj(B.C_A), B.zt(1)) == B.C_B     # 18° の軸での鏡映＝共役のあと ζ を一つ掛ける
    print("二つの向きは軸に対する鏡像（2 種類の奇数）:", "OK" if mirror else "NG")
    two_odd = B.zadd(B.C_A, B.C_B); two_even = B.zadd(B.S_AX, B.C_AX)
    print("二歩ぶんの和：奇数の鎖", two_odd, " 偶数の鎖", two_even, " 一致:", "OK" if two_odd == two_even else "NG")
    v3 = B.zsub(B.unit(3)[2], B.unit(3)[0])
    print("V 字（3 環）の端から端 = 波の 1 周期（二歩ぶん）:", "OK" if v3 == two_odd else "NG")
    print("負の対照：一歩と二歩は違う:", "OK（違う）" if B.C_A != two_odd else "NG")

    print("== 検定4：材料は 2 と 3")
    def two_three(n):
        """n から 3 を引けるときは一度だけ引き（奇数のとき）、残りを 2 ずつ引いていく。引けた 2 の個数と 3 の個数を返す"""
        a, b, r = 0, 0, n
        odd = False; t = n
        while t >= 2: t -= 2
        if t == 1: odd = True
        if odd: r -= 3; b = 1
        while r >= 2: r -= 2; a += 1
        return (a, b) if r == 0 else None
    bad = [n for n in range(2, 1001) if two_three(n) is None]
    print("2〜1000 のどの数も 2a + 3b（a, b ≥ 0）で書ける:", "OK" if not bad else f"NG {bad[:5]}")
    print("立った波の周期を 2 と 3 で:", ", ".join(f"{p}=" + "+".join(["2"] * two_three(p)[0] + ["3"] * two_three(p)[1]) for p in waves[:6]))
